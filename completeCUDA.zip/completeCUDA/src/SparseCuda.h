/*
 * SparseCuda.h
 *
 *  Created on: Sep 20, 2020
 *      Author: hannan
 */

#ifndef SPARSECUDA_H_
#define SPARSECUDA_H_



#include <stdio.h>
#include <stdlib.h>
#include <iostream>

#include <cuda.h>

#include <cuda_runtime.h>
#include <cusparse.h>

#include <boost/thread.hpp>


typedef enum {
    V_Dprecision = 0,
    V_Sprecision  = 1
} cusValueType;

typedef enum {
    I_Dprecision = 0,
    I_Sprecision  = 1
} cusIndexType;

using std::cout;
using std::endl;

#define NUM_THREADS 2
#define StreamSize 4

template <class Ind, class Val>
class SparseCuda {


private:

	boost::thread* t1;
	boost::thread* t2;

//	const int StreamSize = 4;

	int ID = 0;

    float alpha = 1;
    float beta = 0;

	int Mat_Row = 0;
	int Mat_Cols = 0;
	int Mat_NNZ = 0;
	int Mat_Larger = 0;

    Ind     *hA_csrOffsets;
    Ind    	*hA_columns;
    Val	*hA_values;
    Val 	*hX;
    Val	*hY;

    Ind   *dA_csrOffsets, *dA_columns;
    Val *dA_values, *dX, *dY;

	void*                dBuffer    = NULL;
	size_t               bufferSize = 0;

    pthread_t threads[NUM_THREADS];
    int rc;

    cudaStream_t stream[StreamSize];

    cudaError_t cudaFuncResult;

    cusparseHandle_t     handle = NULL;
	cusparseSpMatDescr_t matA;
	cusparseMatDescr_t matA1 = 0;
	cusparseDnVecDescr_t vecX, vecY;

	cusparseStatus_t status;


	void HostMemAlloc();
	void DevMemAlloc();
public:
	SparseCuda(int DeviD);

	cusValueType Val_type;
	cusIndexType Index_type;


	virtual ~SparseCuda();


	int InitMemory(int, int, int, cusValueType , cusIndexType );
	int cuMult(int);



};

#endif /* SPARSECUDA_H_ */
