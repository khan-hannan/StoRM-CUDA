/*
 * test1.h
 *
 *  Created on: Sep 25, 2020
 *      Author: hannan
 */

#ifndef TEST1_H_
#define TEST1_H_

template<class T>
class test1 {
public:
	test1();
	virtual ~test1();
};

#endif /* TEST1_H_ */
