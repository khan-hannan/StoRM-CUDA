/*
 * test1.cpp
 *
 *  Created on: Sep 25, 2020
 *      Author: hannan
 */

#include "test1.h"

template<class T>
test1<T>::test1() {
	// TODO Auto-generated constructor stub

}

template<class T>
test1<T>::~test1() {
	// TODO Auto-generated destructor stub
}

template class test1<int>;
template class test1<double>;
