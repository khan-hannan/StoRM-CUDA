/*
 * Globalcuda.h
 *
 *  Created on: Jan 21, 2021
 *      Author: hannan
 */

#ifndef SRC_GLOBALCUDA_H_
#define SRC_GLOBALCUDA_H_

#include "StormcuSpar.h"

extern StormcuSpar<int, double> *GlobalCuda;



#endif /* SRC_GLOBALCUDA_H_ */
