/*
 * Swap.h
 *
 *  Created on: Sep 7, 2020
 *      Author: hannan
 */

#ifndef SRC_SWAP_H_
#define SRC_SWAP_H_

extern "C" void SwapWrapper(double* Dst, double* Src, int S, int blocks, int threads);



#endif /* SRC_SWAP_H_ */
