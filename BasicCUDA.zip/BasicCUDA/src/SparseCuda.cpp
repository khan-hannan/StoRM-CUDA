/*
 * SparseCuda.cpp
 *
 *  Created on: Sep 20, 2020
 *      Author: hannan
 */

#include "SparseCuda.h"

template <class Ind, class Val>
SparseCuda<Ind,Val>::SparseCuda(int DevID) {

	int DeviceCount = 0;

	cudaGetDeviceCount(&DeviceCount);

	if (DeviceCount > 0){

		cudaSetDevice(DevID);

		cudaFree(0);

	    for (int i = 0; i < StreamSize; ++i) {
	    	cudaStreamCreate(&stream[i]);
		}

		status = cusparseCreate(&handle);
		if (status != CUSPARSE_STATUS_SUCCESS) {
			printf("CUSPARSE API failed at line %d with error: %s (%d)\n", __LINE__, cusparseGetErrorString(status), status);
		}


	}
	else {
		cout<<"No CUDA device found"<<endl;

		exit(0);
	}



}

template <class Ind, class Val>
SparseCuda<Ind,Val>::~SparseCuda() {
	// TODO Auto-generated destructor stub
	t1->join();
	t2->join();
	delete t1;
	delete t2;



	if (hX != NULL)
		cudaFreeHost(hX);
	if (hY != NULL)
		cudaFreeHost(hY);
	if (hA_csrOffsets != NULL)
		cudaFreeHost(hA_csrOffsets);
	if (hA_columns != NULL)
		cudaFreeHost(hA_columns);
	if (hA_values != NULL)
		cudaFreeHost(hA_values);

	if (dX != NULL)
		cudaFree(dX);
	if (dY != NULL)
		cudaFree(dY);
	if (dA_csrOffsets != NULL)
		cudaFree(dA_csrOffsets);
	if (dA_columns != NULL)
		cudaFree(dA_columns);
	if (dA_values != NULL)
		cudaFree(dA_values);

    cusparseDestroyDnVec(vecX);
    cusparseDestroyDnVec(vecY);
    cusparseDestroySpMat(matA);
    cusparseDestroy(handle);

}

template <class Ind, class Val>
void SparseCuda<Ind,Val>::HostMemAlloc() {

		cudaFuncResult = cudaMallocHost((void **) &hX, (Mat_Larger)*sizeof(float));
		if (cudaFuncResult != cudaSuccess) {
			std::cout << "Could not allocate memory for hX, Error Code " << cudaFuncResult << "." << std::endl;
		}

		cudaFuncResult = cudaMallocHost((void **) &hY, (Mat_Larger)*sizeof(float));
		if (cudaFuncResult != cudaSuccess) {
			std::cout << "Could not allocate memory for hY, Error Code " << cudaFuncResult << "." << std::endl;
		}

	    cudaFuncResult = cudaMallocHost((void **) &hA_csrOffsets, (Mat_Row+1)*sizeof(int));
		if (cudaFuncResult != cudaSuccess) {
			std::cout << "Could not allocate memory for hA_csrOffsets, Error Code " << cudaFuncResult << "." << std::endl;
		}

	    cudaFuncResult = cudaMallocHost((void **) &hA_columns, (Mat_NNZ)*sizeof(int));
		if (cudaFuncResult != cudaSuccess) {
			std::cout << "Could not allocate memory for hA_columns, Error Code " << cudaFuncResult << "." << std::endl;
		}

	    cudaFuncResult = cudaMallocHost((void **) &hA_values, (Mat_NNZ)*sizeof(float));
		if (cudaFuncResult != cudaSuccess) {
			std::cout << "Could not allocate memory for hA_values, Error Code " << cudaFuncResult << "." << std::endl;
		}

}


template <class Ind, class Val>
void SparseCuda<Ind,Val>::DevMemAlloc() {


	cudaFuncResult = cudaMalloc((void **) &dA_csrOffsets, (Mat_Row+1)*sizeof(int));
	if (cudaFuncResult != cudaSuccess) {
		std::cout << "Could not allocate memory for dA_csrOffsets, Error Code " << cudaFuncResult << "." << std::endl;
	}
	cudaFuncResult = cudaMalloc((void **) &dA_columns, (Mat_NNZ)*sizeof(int));
	if (cudaFuncResult != cudaSuccess) {
		std::cout << "Could not allocate memory for dA_columns, Error Code " << cudaFuncResult << "." << std::endl;
	}
	cudaFuncResult = cudaMalloc((void **) &dA_values, (Mat_NNZ)*sizeof(float));
	if (cudaFuncResult != cudaSuccess) {
		std::cout << "Could not allocate memory for dA_values, Error Code " << cudaFuncResult << "." << std::endl;
	}
	cudaFuncResult = cudaMalloc((void **) &dX, (Mat_Larger)*sizeof(float));
	if (cudaFuncResult != cudaSuccess) {
		std::cout << "Could not allocate memory for dX, Error Code " << cudaFuncResult << "." << std::endl;
	}
	cudaFuncResult = cudaMalloc((void **) &dY, (Mat_Larger)*sizeof(float));
	if (cudaFuncResult != cudaSuccess) {
		std::cout << "Could not allocate memory for dY, Error Code " << cudaFuncResult << "." << std::endl;
	}

}



template <class Ind, class Val>
int SparseCuda<Ind,Val>::InitMemory(int Rows, int Cols, int NNZ, cusValueType VT, cusIndexType IT){

	Mat_Row = Rows;
	Mat_Cols = Cols;
	Mat_NNZ = NNZ;
	Mat_Larger = (Rows > Cols)?Rows:Cols;


	t1 = new boost::thread(boost::bind(&SparseCuda<Ind, Val>::HostMemAlloc, this));
	t2 = new boost::thread(boost::bind(&SparseCuda<Ind, Val>::DevMemAlloc, this));



	if (VT == V_Dprecision){

		if (IT == I_Dprecision)
			status = cusparseCreateCsr(&matA, Mat_Row, Mat_Cols, Mat_NNZ,
		            dA_csrOffsets, dA_columns, dA_values,
					CUSPARSE_INDEX_64I, CUSPARSE_INDEX_64I,
		            CUSPARSE_INDEX_BASE_ZERO, CUDA_R_64F);

		else
			status = cusparseCreateCsr(&matA, Mat_Row, Mat_Cols, Mat_NNZ,
		            dA_csrOffsets, dA_columns, dA_values,
		            CUSPARSE_INDEX_32I, CUSPARSE_INDEX_32I,
		            CUSPARSE_INDEX_BASE_ZERO, CUDA_R_64F);


		if (status != CUSPARSE_STATUS_SUCCESS) {
			printf("CUSPARSE API failed at line %d with error: %s (%d)\n", __LINE__, cusparseGetErrorString(status), status);
			return -1;
		}

		cusparseCreateMatDescr(&matA1);
		cusparseSetMatIndexBase(matA1, CUSPARSE_INDEX_BASE_ZERO);
		cusparseSetMatType(matA1, CUSPARSE_MATRIX_TYPE_GENERAL);

		status = cusparseCreateDnVec(&vecX, Mat_Cols, dX, CUDA_R_64F);
		if (status != CUSPARSE_STATUS_SUCCESS) {
			printf("CUSPARSE API failed at line %d with error: %s (%d)\n", __LINE__, cusparseGetErrorString(status), status);
		}



		status = cusparseCreateDnVec(&vecY, Mat_Row, dY, CUDA_R_64F);
		if (status != CUSPARSE_STATUS_SUCCESS) {
			printf("CUSPARSE API failed at line %d with error: %s (%d)\n", __LINE__, cusparseGetErrorString(status), status);
		}

		status = cusparseSpMV_bufferSize(
										  handle, CUSPARSE_OPERATION_NON_TRANSPOSE,
										  &alpha, matA, vecX, &beta, vecY, CUDA_R_64F,
										  CUSPARSE_CSRMV_ALG1, &bufferSize);
		if (status != CUSPARSE_STATUS_SUCCESS) {
			printf("CUSPARSE API failed at line %d with error: %s (%d)\n", __LINE__, cusparseGetErrorString(status), status);
		}


	}
	else{
		if (IT == I_Dprecision)
			status = cusparseCreateCsr(&matA, Mat_Row, Mat_Cols, Mat_NNZ,
		            dA_csrOffsets, dA_columns, dA_values,
					CUSPARSE_INDEX_64I, CUSPARSE_INDEX_64I,
		            CUSPARSE_INDEX_BASE_ZERO, CUDA_R_32F);

		else
			status = cusparseCreateCsr(&matA, Mat_Row, Mat_Cols, Mat_NNZ,
		            dA_csrOffsets, dA_columns, dA_values,
		            CUSPARSE_INDEX_32I, CUSPARSE_INDEX_32I,
		            CUSPARSE_INDEX_BASE_ZERO, CUDA_R_32F);


		if (status != CUSPARSE_STATUS_SUCCESS) {
			printf("CUSPARSE API failed at line %d with error: %s (%d)\n", __LINE__, cusparseGetErrorString(status), status);
			return -1;
		}

		cusparseCreateMatDescr(&matA1);
		cusparseSetMatIndexBase(matA1, CUSPARSE_INDEX_BASE_ZERO);
		cusparseSetMatType(matA1, CUSPARSE_MATRIX_TYPE_GENERAL);


		status = cusparseCreateDnVec(&vecX, Mat_Cols, dX, CUDA_R_32F);
		if (status != CUSPARSE_STATUS_SUCCESS) {
			printf("CUSPARSE API failed at line %d with error: %s (%d)\n", __LINE__, cusparseGetErrorString(status), status);
		}

		status = cusparseCreateDnVec(&vecY, Mat_Row, dY, CUDA_R_32F);
		if (status != CUSPARSE_STATUS_SUCCESS) {
			printf("CUSPARSE API failed at line %d with error: %s (%d)\n", __LINE__, cusparseGetErrorString(status), status);
		}

		status = cusparseSpMV_bufferSize(
										  handle, CUSPARSE_OPERATION_NON_TRANSPOSE,
										  &alpha, matA, vecX, &beta, vecY, CUDA_R_32F,
										  CUSPARSE_CSRMV_ALG1, &bufferSize);
		if (status != CUSPARSE_STATUS_SUCCESS) {
			printf("CUSPARSE API failed at line %d with error: %s (%d)\n", __LINE__, cusparseGetErrorString(status), status);
		}
	}

	cudaFuncResult = cudaMalloc(&dBuffer, bufferSize);
	if (cudaFuncResult != cudaSuccess) {
		std::cout << "Could not allocate memory for dBuffer , Error Code " << cudaFuncResult << "." << std::endl;
	}





	return 0;
}

template <class Ind, class Val>
int SparseCuda<Ind,Val>::cuMult(int rounds){

	if (rounds < 1){
		return -1;
	}

	for (int Loop = 0; Loop < rounds; ++Loop) {
		status = cusparseSpMV(handle, CUSPARSE_OPERATION_NON_TRANSPOSE,
										 &alpha, matA, vecX, &beta, vecY, CUDA_R_64F,
										 CUSPARSE_CSRMV_ALG1, dBuffer);
		if (status != CUSPARSE_STATUS_SUCCESS) {
				printf("CUSPARSE API failed at line %d with error: %s (%d)\n", __LINE__, cusparseGetErrorString(status), status);
				return -1;
		}

		if (Loop < rounds-1)
		{
			Val *Temp = dX;
			dX = dY;
			dY = Temp;

			status = cusparseDnVecSetValues(vecX, dX);
			status = cusparseDnVecSetValues(vecY, dY);
			if (status != CUSPARSE_STATUS_SUCCESS) {
					printf("CUSPARSE API failed at line %d with error: %s (%d)\n", __LINE__, cusparseGetErrorString(status), status);
					return -1;
			}
		}
	}

	cudaFuncResult = cudaMemcpy(hY, dY, (Mat_Row)*sizeof(double), cudaMemcpyDeviceToHost);
	if (cudaFuncResult != cudaSuccess) {
		std::cout << "Could not Memcpy values back, Error Code " << cudaFuncResult << "." << std::endl;
		return -1;
	}

	return 0;

}


