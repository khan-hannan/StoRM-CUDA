/*
 * StoRM - Build-in Options
 *
 * This file is parsed by CMake during makefile generation
 */

#ifndef STORM_CUDAPLUGIN_GENERATED_STORMCONFIG_H_
#define STORM_CUDAPLUGIN_GENERATED_STORMCONFIG_H_

// Version Information
#define STORM_CUDAPLUGIN_VERSION_MAJOR 1					// The major version of StoRM
#define STORM_CUDAPLUGIN_VERSION_MINOR 4					// The minor version of StoRM
#define STORM_CUDAPLUGIN_VERSION_PATCH 1					// The patch version of StoRM
#define STORM_CUDAPLUGIN_VERSION_COMMITS_AHEAD 20 	// How many commits passed since the tag was last set
#define STORM_CUDAPLUGIN_VERSION_HASH "gee3c08a08" 					// The short hash of the git commit this build is bases on
#define STORM_CUDAPLUGIN_VERSION_DIRTY 0 					// 0 iff there no files were modified in the checkout, 1 else

// Whether the size of float in a pair<uint_fast64_t, float> is expanded to 64bit
#define STORM_CUDAPLUGIN_HAVE_64BIT_FLOAT_ALIGNMENT

#endif // STORM_CUDAPLUGIN_GENERATED_STORMCONFIG_H_
