//============================================================================
// Name        : P2_Comb_Matrix.cpp
// Author      : hannan
// Version     :
// Copyright   : free to use
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <stdio.h>
#include <stdlib.h>
#include <fstream>

#include <cuda.h>

#include <cuda_runtime.h>
#include <cusparse.h>


#include "storm/api/storm.h"

#include <storm/storage/SparseMatrix.h>
#include <storm-cuda/kernels/cudaForStorm.h>
#include <storm-config.h>

#include "storm/utility/macros.h"
#include "storm/utility/initialize.h"
#include "storm/api/storm.h"

#include "storm/utility/cli.h"
#include "storm-cli-utilities/cli.h"
#include "storm-cli-utilities/model-handling.h"

#include "storm/solver/Multiplier.h"

#include "storm-parsers/api/storm-parsers.h"

#include "storm/utility/macros.h"

#include "Swap.h"

#include <boost/chrono.hpp>

#include "StormcuSpar.h"
#include "storm-config.h"

//#include "test1.h"

//#define W2File

#pragma pack(push, 1) // exact fit - no padding
struct PointFull {
    double lat;
    double lon;
};
#pragma pack(pop)

int main(const int argc,const char **argv)
{

	cudaDeviceProp prop;
	int devId = 0;
	cudaGetDeviceProperties(&prop, devId);
	printf("Device : %s\n", prop.name);
	cudaSetDevice(devId);
//	STORM_LOG_DEBUG("my name is hannan khan");

	StormcuSpar<int, double> CudaValTest1(devId);

//	test1<int> hello;


    storm::utility::setUp();
    storm::cli::printHeader("Storm-cuda", argc, argv);
    storm::settings::initializeAll("Storm-cuda", "storm-cuda");

    if (!storm::cli::parseOptions(argc, argv)) {
        return -1;
    }


    // Start by setting some urgent options (log levels, resources, etc.)
	storm::cli::setUrgentOptions();

        // Parse input file
	storm::cli::SymbolicInput symbolicInput = storm::cli::parseSymbolicInput(storm::builder::BuilderType::Explicit);
	STORM_LOG_THROW(symbolicInput.model.is_initialized(), storm::exceptions::InvalidSettingsException, "No input file set.");


	//	 Build sparse model from input file
	storm::builder::BuilderOptions options;
	auto model = storm::api::buildSparseModel<double>(symbolicInput.model.get(), options);


    // Get transition matrix from Dtmc
    storm::storage::SparseMatrix<double> matrix = model->getTransitionMatrix();

//    storm::storage::SparseMatrixBuilder<double> matrixBuilder(20,4,12);
//
//	matrixBuilder.addNextValue(0, 1, 1.0);
//	matrixBuilder.addNextValue(0, 3, -1.0);
//	matrixBuilder.addNextValue(1, 2, -5.0);
//	matrixBuilder.addNextValue(1, 3, 2.0);
//	matrixBuilder.addNextValue(2, 2, 4.0);
//	matrixBuilder.addNextValue(4, 2, 4.0);
//	matrixBuilder.addNextValue(7, 0, 1.0);
//	matrixBuilder.addNextValue(7, 1, 1.0);
//	matrixBuilder.addNextValue(12, 0, 2.0);
//	matrixBuilder.addNextValue(12, 1, 2.0);
//	matrixBuilder.addNextValue(15, 3, 4.0);
//	matrixBuilder.addNextValue(19, 1, 2.0);
//	storm::storage::SparseMatrixBuilder<double> matrixBuilder(5,4,12);
//
//	matrixBuilder.addNextValue(0, 1, 1.0);
//	matrixBuilder.addNextValue(0, 3, -1.0);
//	matrixBuilder.addNextValue(1, 0, 8.0);
//	matrixBuilder.addNextValue(1, 1, 7.0);
//	matrixBuilder.addNextValue(1, 2, -5.0);
//	matrixBuilder.addNextValue(1, 3, 2.0);
//	matrixBuilder.addNextValue(2, 0, 2.0);
//	matrixBuilder.addNextValue(2, 1, 2.0);
//	matrixBuilder.addNextValue(2, 2, 4.0);
//	matrixBuilder.addNextValue(3, 3, 4.0);
//	matrixBuilder.addNextValue(4, 1, 2.0);
//	matrixBuilder.addNextValue(4, 2, 4.0);

//	storm::storage::SparseMatrix<double> matrix;
//	matrix = matrixBuilder.build();

    std::cout << "Matrix of size " << matrix.getRowCount() << " x " << matrix.getColumnCount() << std::endl;

    int Status;

    storm::Environment env;
    // Create multiplier
    auto factory = storm::solver::MultiplierFactory<double>();
    auto multiplier = factory.create(env, matrix);

    int A_num_rows = matrix.getRowCount();
    int A_num_cols = matrix.getColumnCount();
    int A_num_nnz  = matrix.getNonzeroEntryCount();



    std::cout<<"Non zero values = "<<A_num_nnz<<std::endl;

    std::cout<< "Sparsity = "<<(((A_num_rows*A_num_cols) - A_num_nnz) / (A_num_cols*A_num_rows))<<std::endl;

    if (CudaValTest1.InitMemory(A_num_rows, A_num_cols, A_num_nnz) == -1){
    	std::cout<<"Fail at Init Memory"<<std::endl;
    	return -1;
    }

    int LargerSize = (A_num_rows > A_num_cols)?A_num_rows:A_num_cols;

    int LoopTimes = 2;


	cusparseStatus_t status;
//
	std::vector<storm::storage::MatrixEntry<uint_fast64_t, double>> PcolumnsAndValues;
	std::vector<uint_fast64_t> ProwIndications;
//
    cudaError_t cudaMallocResult;

    matrix.Val_Return(PcolumnsAndValues, ProwIndications);

#ifdef W2File
    std::fstream file;
    file.open("ha_csr.bin", std::ios::out | std::ios::binary);
    if (!file){
    	std::cout<<"csr file fault"<<std::endl;
    	return -1;
    }

    file.write((char*)(&A_num_rows), sizeof(int));

	for (int i = 0; i <= A_num_rows; ++i) {
		file.write( (char*)(&ProwIndications[i]), sizeof(uint_fast64_t));
	}

    file.close();

    file.open("ha_X.bin", std::ios::out | std::ios::binary);
    if (!file){
    	std::cout<<"haX file fault"<<std::endl;
    	return -1;
    }
    file.write((char*)(&A_num_cols), sizeof(int));

	for (int i = 0; i < A_num_cols; ++i) {
		file.write( (char*)(&i), sizeof(int));
	}

	file.close();

	file.open("ha_Val.bin", std::ios::out | std::ios::binary);
    if (!file){
    	std::cout<<"haVal file fault"<<std::endl;
    	return -1;
    }

    file.write((char*)(&A_num_nnz), sizeof(int));

	for (int i = 0; i < A_num_nnz; ++i) {

		file.write( (char*)(&PcolumnsAndValues[i].getValue()), sizeof(double));
		file.write( (char*)(&PcolumnsAndValues[i].getColumn()), sizeof(uint_fast64_t));

	}

	file.close();

	return 1;

#endif


	for (int i = 0; i <= A_num_rows; ++i) {
			CudaValTest1.hA_csrOffsets[i] = ProwIndications[i];
	}

	for (int i = 0; i < A_num_cols; ++i) {
		CudaValTest1.hX[i] = i;
	}

	for (int i = 0; i < A_num_nnz; ++i) {
		CudaValTest1.hA_values[i] = PcolumnsAndValues[i].getValue();
		CudaValTest1.hA_columns[i] = PcolumnsAndValues[i].getColumn();
	}

	boost::chrono::high_resolution_clock::time_point astart = boost::chrono::high_resolution_clock::now();


    if(CudaValTest1.cuMult(LoopTimes) == -1){
    	std::cout<<"Fail at Multiplier"<<std::endl;
    	return -1;
    }
	boost::chrono::microseconds ams = boost::chrono::duration_cast<boost::chrono::microseconds> (boost::chrono::high_resolution_clock::now() - astart);
	std::cout << "GPU time took " << ams.count() << "us " << "\n";

    std::vector<double> x(matrix.getRowCount());

    for (size_t i = 0; i < matrix.getColumnCount(); ++i) {
        x[i] = i;
    }


    std::vector<double> b(matrix.getRowCount());
    for (size_t i = 0; i < matrix.getColumnCount(); ++i) {
        b[i] = 0;
    }


//	boost::chrono::high_resolution_clock::time_point astart = boost::chrono::high_resolution_clock::now();
//    basicValueIteration_spmv_uint64_double(matrix.getColumnCount(), ProwIndications, PcolumnsAndValues, x, b);
//	boost::chrono::microseconds ams = boost::chrono::duration_cast<boost::chrono::microseconds> (boost::chrono::high_resolution_clock::now() - astart);
//	std::cout << "GPU time took " << ams.count() << "us " << "\n";

    std::vector<uint_fast64_t> rowGroupIndices = matrix.getRowGroupIndices();

    double endGroups;
    double endRows;


//    multiplier->repeatedMultiplyAndReduce(env, storm::solver::OptimizationDirection::Minimize, x, nullptr, LoopTimes);

    {
		boost::chrono::high_resolution_clock::time_point start = boost::chrono::high_resolution_clock::now();
		multiplier->repeatedMultiply(env, x, nullptr, LoopTimes);
		boost::chrono::microseconds ms = boost::chrono::duration_cast<boost::chrono::microseconds> (boost::chrono::high_resolution_clock::now() - start);
		std::cout << "CPU time took " << ms.count() << "us " << "\n";
    }
    bool result = true;
    int Hold =0 ;

    for (int i = 0; i < A_num_rows; ++i) {

    	if ((x[i] - CudaValTest1.hY[i]) > 0.00001){

    		result = false;

    		Hold = i;
    		break;

    	}

	}

    if (result)
    	std::cout<<"MATCHED " <<std::endl;
    else
    	std::cout<<"Break at : "<<Hold<<std::endl;



	return 0;
}
